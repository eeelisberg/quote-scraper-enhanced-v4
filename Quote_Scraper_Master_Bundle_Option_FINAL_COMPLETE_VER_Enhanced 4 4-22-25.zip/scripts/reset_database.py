# This script resets the quote database
def reset():
    print('Resetting...')